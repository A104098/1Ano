module Tarefa1_2021li1g069_Spec where

import Test.HUnit
import LI12122
import Tarefa1_2021li1g069
import Fixtures

-- Tarefa 1
testsT1 =
  test
    [ "Tarefa 1 - Teste Valida Mapa m1r" ~: validaPotencialMapa m1 ~=? True
    , "Tarefa 1 - Teste Valida Mapa vazio" ~: validaPotencialMapa [] ~=? False
    , "Tarefa 1 - Teste Valida Mapa com 2 portas" ~: validaPotencialMapa [(Porta, (0,0)), (Porta, (1,0))] ~=?  False
    , "Tarefa 1 - Teste Valida Mapa com duas peças na mesma posição" ~: validaPotencialMapa [(Bloco, (0,0)), (Caixa, (0,0))] ~=? False
    , "Tarefa 1 - Teste Valida Mapa com caixa flutuante" ~: validaPotencialMapa [(Caixa, (0,0)), (Vazio, (0,1)), (Bloco, (0,2))] ~=? False
    , "Tarefa 1 - Teste Valida Mapa sem espaços vazios" ~: validaPotencialMapa [(Bloco, (0,0))] ~=? False 
    , "Tarefa 1 - Teste Valida Mapa cuja base não é unicamente composta por blocos" ~: validaPotencialMapa [(Bloco, (0,0)), (Caixa, (1,0))] ~=? False

    ]
 