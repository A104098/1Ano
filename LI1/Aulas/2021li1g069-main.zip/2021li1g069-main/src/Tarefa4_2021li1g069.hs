{- |
Module      : Tarefa4_2021li1g069
Description : Movimentação do personagem
Copyright   : João Pereira <a96350@alunos.uminho.pt>;
            : Luís Borges <a96357@alunos.uminho.pt>;

Módulo para a realização da Tarefa 4 do projeto de LI1 em 2021/22.
-}
module Tarefa4_2021li1g069 where

import LI12122
import Tarefa1_2021li1g069
import Tarefa3_2021li1g069 
import Tarefa2_2021li1g069


{- | Recebe um jogo e uma lista de movimentos e devolve o jogo depois dos movimentos serem efetuados -}   
correrMovimentos :: Jogo -> [Movimento] -> Jogo 
correrMovimentos (Jogo m (Jogador (a,b) c d)) [] = (Jogo m (Jogador (a,b) c d))
correrMovimentos (Jogo m (Jogador (a,b) c d)) (h:t) = correrMovimentos (moveJogador (Jogo m (Jogador (a,b) c d)) h) t


{- | Recebe um jogo e um movimento e devolve o jogo depois do movimento ser efetuado.
Para cada movimento, verifica se é possível.
Se for, executa-o.
Se não for, o jogo fica como estava. -}
moveJogador :: Jogo -> Movimento -> Jogo 
moveJogador (Jogo  m (Jogador (a,b) c d )) AndarEsquerda       | ((checkIfPossible (Jogo m (Jogador (a,b) c d ))) AndarEsquerda == True) && ((vaiParaOnde == Vazio) || (vaiParaOnde == Porta)) = Jogo m (Jogador (cairOnde (desconstroiMapa m) (a,b) AndarEsquerda) Oeste d) 
                                                               | otherwise = (Jogo  m (Jogador (a,b) Oeste d ))
   where vaiParaOnde = getPeca (cairOnde (desconstroiMapa m) (a,b) AndarEsquerda) m


moveJogador (Jogo  m (Jogador (a,b) c d )) AndarDireita        | ((checkIfPossible (Jogo m (Jogador (a,b) c d ))) AndarDireita == True) && ((vaiParaOnde == Vazio) || (vaiParaOnde == Porta)) = Jogo m (Jogador (cairOnde (desconstroiMapa m) (a,b) AndarDireita) Este d)
                                                               | otherwise = (Jogo  m (Jogador (a,b) Este d ))
   where vaiParaOnde = getPeca (cairOnde (desconstroiMapa m) (a,b) AndarDireita) m

moveJogador (Jogo  m (Jogador (a,b) Este d )) Trepar           | ((checkIfPossible (Jogo m (Jogador (a,b) Este d ))) Trepar == True) = Jogo m (Jogador (a+1,b-1) Este d) 
                                                               | otherwise = (Jogo  m (Jogador (a,b) Este d ))
moveJogador (Jogo  m (Jogador (a,b) Oeste d )) Trepar          | ((checkIfPossible (Jogo m (Jogador (a,b) Oeste d ))) Trepar == True) = Jogo m (Jogador (a-1,b-1) Oeste d) 
                                                               | otherwise = (Jogo  m (Jogador (a,b) Oeste d ))
moveJogador (Jogo m (Jogador (a,b) Este True)) InterageCaixa   | ((checkIfPossible (Jogo m (Jogador (a,b) Este True)) InterageCaixa) == True) = Jogo (addCaixa m (a,b) Este) (Jogador (a,b) Este False)  
                                                               | otherwise = (Jogo m (Jogador (a,b) Este True))
moveJogador (Jogo m (Jogador (a,b) Oeste True)) InterageCaixa  | ((checkIfPossible (Jogo m (Jogador (a,b) Oeste True)) InterageCaixa) == True) = Jogo (addCaixa m (a,b) Oeste) (Jogador (a,b) Oeste False)  
                                                               | otherwise = (Jogo m (Jogador (a,b) Oeste True))
moveJogador (Jogo m (Jogador (a,b) Este False)) InterageCaixa  | ((checkIfPossible (Jogo m (Jogador (a,b) Este False)) InterageCaixa) == True) = Jogo (constroiMapa (delCaixa (desconstroiMapa m) (a,b) Este)) (Jogador (a,b) Este True)
                                                               | otherwise = (Jogo m (Jogador (a,b) Este False))
moveJogador (Jogo m (Jogador (a,b) Oeste False)) InterageCaixa | ((checkIfPossible (Jogo m (Jogador (a,b) Oeste False)) InterageCaixa) == True) = Jogo (constroiMapa (delCaixa (desconstroiMapa m) (a,b) Oeste)) (Jogador (a,b) Oeste True)
                                                               | otherwise = (Jogo m (Jogador (a,b) Oeste False))
   where vaiParaOnde = getPeca (cairOnde (desconstroiMapa m) (a,b) AndarEsquerda) m

{- | Quando o jogador anda para a direita ou para a esquerda, pode ter que cair vários blocos ao mesmo tempo.
Assim, esta função serve para descobrir quais as são as coordenadas para as quais o jogador deve ir ao executar o movimento AndarDireita ou AndarEsquerda. -}
cairOnde :: [(Peca, Coordenadas)] -> Coordenadas -> Movimento -> Coordenadas
cairOnde (m:ms) (a,b) AndarEsquerda | (getPeca (a-1,b) (constroiMapa (m:ms))) == Porta = (a-1,b)
                                    | (getPeca (a-1,b) (constroiMapa (m:ms))) == Vazio = (cairOnde (m:ms) (a,b+1) AndarEsquerda)
                                    | otherwise                                        = (a-1, b-1)    
cairOnde (m:ms) (a,b) AndarDireita  | (getPeca (a+1,b) (constroiMapa (m:ms))) == Porta = (a+1,b)
                                    | (getPeca (a+1,b) (constroiMapa (m:ms))) == Vazio = (cairOnde (m:ms) (a,b+1) AndarDireita)
                                    | otherwise = (a+1, b-1)


{- | Verifica se para um certo Jogo, certo movimento é possível. -}
checkIfPossible :: Jogo -> Movimento -> Bool
checkIfPossible (Jogo  (m:ms) (Jogador (a,b) c d )) mov | (mov == AndarEsquerda) && (a /= 0) && (pecaVaziaOuPorta (m:ms) (a-1,b) == True) = True
                                                        | (mov == AndarDireita) && ((a+1) < (length m)) && (pecaVaziaOuPorta (m:ms) (a+1,b) == True) = True --assume q todas as listas dentro do mapa têm a mesma length (acho q têm q ter)
                                                        | (mov == Trepar) && (c == Este) && ((a+1) < (length m)) && (pecaVazia (m:ms) (a+1,b-1) == True) && ((getPeca (a+1,b) (m:ms) == Bloco) || (getPeca (a+1,b) (m:ms) == Caixa)) = True 
                                                        | (mov == Trepar) && (c == Oeste) && (a /= 0)  && (pecaVazia (m:ms) (a-1,b-1) == True) && ((getPeca (a-1,b) (m:ms) == Bloco) || (getPeca (a-1,b) (m:ms) == Caixa)) = True
                                                        | (mov == InterageCaixa) && (c == Este) && ((a+1) < (length m)) && (d == True) && (pecaVazia (m:ms) (a+1,b-1) == True) = True
                                                        | (mov == InterageCaixa) && (c == Este) && ((a+1) < (length m)) && (d == False) && (pecaVazia (m:ms) (a+1,b-1) == True) && (pecaVazia (m:ms) (a,b-1) == True) && (getPeca (a+1,b) (m:ms) == Caixa) = True
                                                        | (mov == InterageCaixa) && (c == Oeste) && (a /= 0) && (d == True) && (pecaVazia (m:ms) (a-1,b-1) == True) = True
                                                        | (mov == InterageCaixa) && (c == Oeste) && (a /= 0) && (d == False) && (pecaVazia (m:ms) (a-1,b-1) == True) && (pecaVazia (m:ms) (a,b-1) == True) && (getPeca (a-1,b) (m:ms) == Caixa) = True
                                                        | otherwise = False


{- | Recebe um mapa e um par de coordenadas e verifica se a peça que se encontra nessas coordenadas é Vazia. -}
pecaVazia :: Mapa -> Coordenadas -> Bool   -- qnd dou coordenadas q n estao no mapa a resposta é true 
pecaVazia l (a,b) | (elem (Bloco, (a,b)) (desconstroiMapa l)) || (elem (Caixa, (a,b)) (desconstroiMapa l)) || (elem (Porta, (a,b)) (desconstroiMapa l)) = False
                  | otherwise                                                                                                                           = True 

pecaVaziaOuPorta :: Mapa -> Coordenadas -> Bool   -- qnd dou coordenadas q n estao no mapa a resposta é true 
pecaVaziaOuPorta l (a,b) | (elem (Bloco, (a,b)) (desconstroiMapa l)) || (elem (Caixa, (a,b)) (desconstroiMapa l)) = False
                         | otherwise                                                                              = True

{- | Recebe um par de coordenadas e um mapa e devolve a peça que se encontra nessas coordenadas. -}
getPeca :: Coordenadas -> Mapa -> Peca   
getPeca (a,b) ((m:ms):t) | (b /= 0) = getPeca (a, b-1) t 
                         | (b == 0) && (a /= 0) = getPeca (a-1,b) (ms:t)
                         | (b == 0) && (a == 0) = m   

{- | Recebe um mapa, um par de coordenadas e uma direção e, conforme os valores recebidos, adiciona ao mapa uma caixa em certas coordenadas. -} 
addCaixa :: Mapa -> Coordenadas -> Direcao -> Mapa 
addCaixa m (a,b) Este  | ((getPeca (a+1,b) m) == Vazio) = addCaixa m (a,b+1) Este  
                       | otherwise                      = constroiMapa ((desconstroiMapa m) ++ [(Caixa, (a+1,b-1))])
addCaixa m (a,b) Oeste | ((getPeca (a-1,b) m) == Vazio) = addCaixa m (a,b+1) Oeste  
                       | otherwise                        = constroiMapa ((desconstroiMapa m) ++ [(Caixa, (a-1,b-1))])

{- | Receba uma lista de pares (Peca, Coordenadas), um par de coordenadas e uma direção e, conforme os valores recebidos, elimina da lista uma caixa em certas coordenadas. -}
delCaixa :: [(Peca, Coordenadas)] -> Coordenadas -> Direcao -> [(Peca, Coordenadas)] 
delCaixa [] (a2,b2) d = []
delCaixa ((p, (a1,b1)):as) (a2,b2) Este  | (a1,b1) == (a2+1,b2) = as 
                                         | otherwise            = ((p, (a1,b1))):(delCaixa as (a2,b2) Este)
delCaixa ((p, (a1,b1)):as) (a2,b2) Oeste | (a1,b1) == (a2-1,b2) = as 
                                         | otherwise            = ((p, (a1,b1))):(delCaixa as (a2,b2) Oeste)                                       


