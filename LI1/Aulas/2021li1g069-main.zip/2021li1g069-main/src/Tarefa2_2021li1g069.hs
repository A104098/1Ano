{- |
Module      : Tarefa2_2021li1g069
Description : Construção/Desconstrução do mapa
Copyright   : João Pereira <a96350@alunos.uminho.pt>;
            : Luís Borges <a96357@alunos.uminho.pt>;

Módulo para a realização da Tarefa 2 do projeto de LI1 em 2021/22.
-}
module Tarefa2_2021li1g069 where

import LI12122
import Tarefa1_2021li1g069

{- |  Constrói um mapa a partir de uma lista de pares (Peca, Coordenadas).-}
constroiMapa :: [(Peca, Coordenadas)] -> Mapa
constroiMapa [] = []
constroiMapa (a:as) = map apenasPeca (substituiNoMapa (constroiMapaAux1 (a:as) 0) (addCords (mapaVazio (a:as)) 0 0))

{- | constrói uma lista de listas de pares (Peca, Coordenadas) a partir de uma lista de pares (Peca, Coordenadas) e de um Int.
a função gerarLista é aplicada recursivamente enquanto o inteiro for menos do que a maior ordeanda da lista.-}
constroiMapaAux1 :: [(Peca, Coordenadas)] -> Int -> [[(Peca, Coordenadas)]]
constroiMapaAux1 [] x = [[]]
constroiMapaAux1 [(a1, (b1,c1))] x = [[(a1, (b1,c1))]]
constroiMapaAux1 ((a1, (b1,c1)):(a2, (b2,c2)):t) x | x < (maiorY ((a1, (b1,c1)):(a2, (b2,c2)):t)) = [gerarLista x ((a1,(b1,c1)):(a2, (b2,c2)):t)] ++ constroiMapaAux1 ((a1, (b1,c1)):(a2, (b2,c2)):t) (x+1) 
                                                   | otherwise = [(gerarLista x ((a1,(b1,c1)):(a2, (b2,c2)):t))]
{- | Recebe uma lista de pares (Peca, Coordenadas). 
Forma um mapa com as suas dimensões mas apenas com peças vazias. -}
mapaVazio :: [(Peca, Coordenadas)] -> Mapa
mapaVazio t = take ((maiorY t)+1) (repeat (take ((maiorX t)+1) (repeat Vazio)))  

{- | Recebe um mapa e dois inteiros. 
Transforma o mapa numa lista de listas de pares (Peca, Coordenadas).-}
addCords :: Mapa -> Int -> Int -> [[(Peca, Coordenadas)]]
addCords [(a:as)] x y = [fazerLinha (a:as) x y]
addCords ((a:as):t) x y = (fazerLinha (a:as) x y):(addCords t x (y+1)) 

{- | Recebe uma lista de peças e dois inteiros. 
Transforma a lista de peças numa lista de pares (Peca, Coordenadas).-}
fazerLinha :: [Peca] -> Int -> Int -> [(Peca, Coordenadas)]
fazerLinha [a] x y = [(a, (x,y))] 
fazerLinha (a:as) x y = (a, (x,y)):(fazerLinha as (x+1) y)

{- | Recebe duas listas de listas de pares (Peca, Coordenadas).
Se houverem elementos com coordenadas iguais, com ajuda de função auxiliar subLinha, subsitui-se o elemento da primeira lista de listas na segunda.-}
substituiNoMapa :: [[(Peca, Coordenadas)]] -> [[(Peca, Coordenadas)]] -> [[(Peca, Coordenadas)]] 
substituiNoMapa [] l = l
substituiNoMapa ([]:t1) (((a2, (b2,c2)):d2):t2) = ((a2, (b2,c2)):d2):(substituiNoMapa t1 t2)
substituiNoMapa (((a1, (b1,c1)):d1):t1) (((a2, (b2,c2)):d2):t2) | c1 == c2  = (subLinha ((a1, (b1,c1)):d1) ((a2, (b2,c2)):d2)):(substituiNoMapa t1 t2)
                                                                | otherwise = ((a2, (b2,c2)):d2):(substituiNoMapa (((a1, (b1,c1)):d1):t1) t2)       

{- | Função auxiliar da função subsitui no mapa.
Verifica se as coordenadas são iguais e, se sim, procede à subsituição acima referida.-}
subLinha :: [(Peca, Coordenadas)] -> [(Peca, Coordenadas)] -> [(Peca, Coordenadas)]
subLinha [] l = l
subLinha ((a1, (b1,c1)):d1) ((a2, (b2,c2)):d2) | (b1,c1) == (b2,c2) = (a1, (b1,c1)):(subLinha d1 d2)
                                               | otherwise          = (a2, (b2,c2)):(subLinha ((a1, (b1,c1)):d1) d2)

{- | Recebe um inteiro e uma lista de pares (Peca, Coordenadas).
Gera uma linha de pares (Peca, Coordenadas) com todos os elementos com a mesma ordenada.
A linha é gerada de forma ordenada (ou seja, por ordem crescente de abcissa) graças à utilização da função auxiliar inserePeca. -}
gerarLista :: Int -> [(Peca, Coordenadas)] -> [(Peca, Coordenadas)]
gerarLista x [] = []
gerarLista x ((a1, (b1,c1)):t) | x == c1   = (inserePeca (a1,(b1,c1)) (gerarLista x t))
                               | otherwise = gerarLista x t  

{- | Insere um par (Peca, Coordenada) numa lista de pares (Peca, Coordenada) -}
inserePeca :: (Peca, Coordenadas) -> [(Peca, Coordenadas)] -> [(Peca, Coordenadas)]
inserePeca (a1, (b1,c1)) [] = [(a1, (b1,c1))]
inserePeca (a1,(b1,c1)) ((a2, (b2,c2)):t) | (c1 == c2) && (b1 == b2) = (a2, (b2,c2)):t
                                          | (c1 == c2) && (b1 < b2) = ((a1,(b1,c1)):(a2, (b2,c2)):t)
                                          | (c1 < c2) = ((a1,(b1,c1)):(a2, (b2,c2)):t)
                                          | otherwise = (a2, (b2,c2)):(inserePeca (a1,(b1,c1)) t)

{- | Recebe uma lista de pares (Peca, Coordenadas) e retira-lhes as coordenadas. -}
apenasPeca :: [(Peca, Coordenadas)] -> [Peca]
apenasPeca [] = []
apenasPeca ((a1, (b1,c1)):t) = a1:(apenasPeca t)

{- | Transforma um mapa numa lista de pares (Peca, Coordenada) -}
desconstroiMapa :: Mapa -> [(Peca, Coordenadas)]
desconstroiMapa  l = (desconstroiMapaAux1 l 0 0)

{- | Função auxiliar da função desconstroiMapa. 
Recebe o mapa, 2 inteiros (inicialmente ambos iguais a 0) e devolve a lista de pares (Peca, Coordenadas). -}
desconstroiMapaAux1 :: Mapa -> Int -> Int -> [(Peca, Coordenadas)] 
desconstroiMapaAux1 [] x y = []
desconstroiMapaAux1 ([]:t) x y = desconstroiMapaAux1 t 0 (y+1)
desconstroiMapaAux1 ((a:as):t) x y | a == Vazio = desconstroiMapaAux1 (as:t) (x+1) y 
                                   | otherwise  = (a, (x,y)):(desconstroiMapaAux1 (as:t) (x+1) y) 




