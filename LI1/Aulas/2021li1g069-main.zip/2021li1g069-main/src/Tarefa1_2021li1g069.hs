{- |
Module      : Tarefa1_2021li1g069
Description : Validação de um potencial mapa
Copyright   : João Pereira <a96350@alunos.uminho.pt>;
            : Luís Borges <a96357@alunos.uminho.pt>;

Módulo para a realização da Tarefa 1 do projeto de LI1 em 2021/22.
-}
module Tarefa1_2021li1g069 where

import LI12122

{- | Utiliza 5 funções auxiliares para verificar se todas as condições necessárias para o mapa ser válido são cumpridas. -}
validaPotencialMapa :: [(Peca,Coordenadas)] -> Bool
validaPotencialMapa l | ((pecaUnicaPorPosicao l []) == True) && ((portaUnica l 0) == True) && ((caixaNaoFlutuante l l) == True) && ((minimoUmEspacoVazio l) == True) && ((baseSoBlocos l l) == True) = True
                      | otherwise                                                                                                                                                                  = False



{- | Recebe a lista das Peças e respetivas coordenadas e uma lista vazia. 
De forma a verificar que cada posição tem apenas uma peça, testamos, para cada conjunto de coordenadas na primeira lista, se esse conjunto não está na segunda. 
Se não estiver, adicionamos. 
Se estiver, a função retorna False, uma vez que o mapa não é válido, pois há 2 peças na mesma posição. -}
pecaUnicaPorPosicao :: [(Peca,Coordenadas)] -> [Coordenadas] -> Bool 
pecaUnicaPorPosicao [] _ = True
pecaUnicaPorPosicao ((_,(x,y)):as) l | (elem (x,y) l) = False 
                                     | otherwise      = pecaUnicaPorPosicao as ((x,y):l)



{- | Verifica que há apenas 1 porta. 
Recebe a lista de Peças e respetivas coordenadas e um inteiro correspondente ao número de portas (inicialmente 0). 
Adiciona 1 aominteiro cada vez que encontra 1 porta.
Qaundo a lista acabar, se o valor do inteiro for 1, a função retorna True (o mapa tem uma única porta).
Caso contrário, a função retorna False.-}
portaUnica ::  [(Peca, Coordenadas)] -> Int -> Bool
portaUnica [] 1 = True
portaUnica [] _ = False
portaUnica ((a,_):as) z | a == Porta = portaUnica as (z+1)
                        | otherwise  = portaUnica as z



{- | Verifica que, abaixo de cada Caixa, há outra Caixa ou um Bloco.
Para isso recebe a lista de Peças e respetivas coordenadas 2 vezes (a segunda lista serve apenas para consultar e fica sempre inalterada).
Usamos também as funções auxiliares elementoAbaixoCaixa e elementoAbaixoBloco.
-}
caixaNaoFlutuante :: [(Peca, Coordenadas)] -> [(Peca, Coordenadas)] -> Bool
caixaNaoFlutuante [] l = True
caixaNaoFlutuante ((Caixa,(x,y)):as) l | y >= 0 && ((elementoAbaixoCaixa (Bloco,(x,y)) l) || (elementoAbaixoBloco (Bloco,(x,y)) l)) = caixaNaoFlutuante as l
                                       | otherwise                                                                                   = False
caixaNaoFlutuante (_:as) l = caixaNaoFlutuante as l



{- | Verifica, para qualquer elemento, se o elemento imediatamente abaixo é uma caixa. -}
elementoAbaixoCaixa :: (Peca, Coordenadas) -> [(Peca, Coordenadas)] -> Bool
elementoAbaixoCaixa (_,(x,y)) l | (elem (Caixa,(x,(y+1))) l) = True
                                | otherwise                  = False 



{- | Verifica, para qualquer elemento, se o elemento imediatamente abaixo é um bloco. -}
elementoAbaixoBloco :: (Peca, Coordenadas) -> [(Peca, Coordenadas)] -> Bool
elementoAbaixoBloco (_,(x,y)) l | (elem (Bloco,(x,(y+1))) l) = True
                                | otherwise                  = False



{- | Verifica se o mapa tem pelo menos 1 espaço vazio.
A função começa por verificar se o mapa tem algum espaço vazio omitido, através da função verificarOmitidos.
Se existirem omitidos, a função retorna True, porque um espaço só pode ser omitido se for vazio, logo, há pelo menos 1 espaço vazio.
Se não existirem omitidos, usamos a função minimoUmEspacoVazioAux para verificar, um a um, se há algum elemento vazio.-}
minimoUmEspacoVazio :: [(Peca, Coordenadas)] -> Bool
minimoUmEspacoVazio l | (verificarOmitidos l == True) = True
                      | otherwise                     = minimoUmEspacoVazioAux l



{- |Verifica, elemento a elemento, por recursividade, se há algum espaço vazio.-}
minimoUmEspacoVazioAux :: [(Peca, Coordenadas)] -> Bool
minimoUmEspacoVazioAux [] = False
minimoUmEspacoVazioAux ((Vazio,(x,y)):as) = True
minimoUmEspacoVazioAux ((_:as)) = minimoUmEspacoVazioAux as  



{- | Obtém o elemento com maior abcissa. -}
maiorX :: [(Peca,Coordenadas)] -> Int 
maiorX [(Bloco,(x1,y1))] = x1
maiorX [(Vazio,(x1,y1))] = x1
maiorX [(Caixa,(x1,y1))] = x1
maiorX [(Porta,(x1,y1))] = x1
maiorX ((p,(x1,y1)):(q,(x2,y2)):as) | x1>x2     = maiorX ((p,(x1,y1)):as) 
                                    | otherwise = maiorX ((q,(x2,y2)):as) 



{- | Obtém o elemento com maior ordenada. -}
maiorY :: [(Peca,Coordenadas)] -> Int 
maiorY [(Bloco,(x1,y1))] = y1
maiorY [(Vazio,(x1,y1))] = y1
maiorY [(Caixa,(x1,y1))] = y1
maiorY [(Porta,(x1,y1))] = y1
maiorY ((p,(x1,y1)):(q,(x2,y2)):as) | y1>y2     = maiorY ((p,(x1,y1)):as) 
                                    | otherwise = maiorY ((q,(x2,y2)):as) 



{- | Verifica se há elementos omitidos.
Através das funções auxiliares maiorX e maiorY, calcula o total de elementos que a matriz sem omitidos deve ter.
Se o número de elementos da lista for menor, conclui que há elementos omitidos.-}
verificarOmitidos :: [(Peca,Coordenadas)] -> Bool
verificarOmitidos l | ((maiorX l)+1) * ((maiorY l)+1) > length l = True 
                    | otherwise                                  = False   



{- | A função auxiliar baseSoBlocos verifica se a base é composta apenas por Blocos.
Para isso, obtém a maior ordenada (a da base) pela função auxiliar maiorY e verifica, para os elementos com essa ordenada, se são blocos.-}
baseSoBlocos :: [(Peca,Coordenadas)] -> [(Peca,Coordenadas)] -> Bool
baseSoBlocos [] l = True
baseSoBlocos ((p,(x,y)):as) l | (y == (maiorY l)) && (p /= Bloco) = False
                              | otherwise = baseSoBlocos as l
