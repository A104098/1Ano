{- |
Module      : Tarefa6_2021li1g069
Description : Resolução de um Puzzle
Copyright   : João Pereira <a96350@alunos.uminho.pt>;
            : Luís Borges <a96357@alunos.uminho.pt>;

Módulo para a realização da Tarefa 5 do projeto de LI1 em 2021/22.
-}
module Tarefa6_2021li1g069 where 

import LI12122
import Tarefa1_2021li1g069
import Tarefa2_2021li1g069
import Tarefa3_2021li1g069
import Tarefa4_2021li1g069


data QTree l = Empty
             | Node [Movimento] (QTree [Movimento]) (QTree [Movimento]) (QTree [Movimento]) (QTree [Movimento])
         deriving (Show, Eq)


{- | Indica um conjunto de movimentos que resolvem um certo jogo, ou seja, fazem com que o jogador chegue à Porta. -}
resolveJogo :: Int -> Jogo -> Maybe [Movimento]
resolveJogo i jogo = resolveJogoAux i l jogo 
   where l = getListasFromTree (genTree jogo (Node [] Empty Empty Empty Empty) i)


{- | Função auxiliar da resolveJogo, para ser possível usar mais variáveis -}
resolveJogoAux :: Int -> [[Movimento]] -> Jogo -> Maybe [Movimento]
resolveJogoAux i [] jogo = Nothing
resolveJogoAux i (h:t) jogo | length (correrMovimentosAtePorta jogo h []) == 0 = resolveJogoAux i t jogo
                            | otherwise                                        = Just h


{- | A partir de um certo Jogo, forma uma QTree que a acaba quando a length da última lista é igual ao Int dado. -}
genTree :: Jogo -> QTree l -> Int -> QTree l 
genTree jogo (Node l a b c d) x 
  | x == 0 = (Node l a b c d)
  | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
  | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (Empty) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
  | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (Empty)
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
  | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (Empty)
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (Empty) 
                   (Empty)
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (Empty) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (Empty)
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (Empty) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (Empty)
                   (Empty)
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (Empty)
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (Empty)
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == True) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (genTree (moveJogador jogo AndarEsquerda) (Node (l++[AndarEsquerda]) Empty Empty Empty Empty) (x-1)) 
                   (Empty)
                   (Empty)
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == True)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (Empty) 
                   (genTree (moveJogador jogo AndarDireita)  (Node (l++[AndarDireita])  Empty Empty Empty Empty) (x-1))
                   (Empty)
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == True)  && ((movMudaJogo jogo InterageCaixa) == False) =
           (Node l (Empty)
                   (Empty)
                   (genTree (moveJogador jogo Trepar)        (Node (l++[Trepar])        Empty Empty Empty Empty) (x-1))
                   (Empty))
 | (x/=0) && ((movMudaJogo jogo AndarEsquerda) == False) && ((movMudaJogo jogo AndarDireita) == False)  && ((movMudaJogo jogo Trepar) == False)  && ((movMudaJogo jogo InterageCaixa) == True) =
           (Node l (Empty) 
                   (Empty)
                   (Empty)
                   (genTree (moveJogador jogo InterageCaixa) (Node (l++[InterageCaixa]) Empty Empty Empty Empty) (x-1)))

 
{- | Verifica se um certo movimento muda alguma coisa no Jogo. -}
movMudaJogo :: Jogo -> Movimento -> Bool 
movMudaJogo jogo t | (jogoComMov == jogo) = False 
                   | otherwise            = True
    where jogoComMov = moveJogador jogo t


{- | Obtém as listas de movimentos finais, na árvore. -}
getListasFromTree :: QTree l -> [[Movimento]]
getListasFromTree Empty = []
getListasFromTree (Node l a b c d) | (a==Empty) && (b==Empty) && (c==Empty) && (d==Empty) = [l]
                                   | otherwise  = (getListasFromTree a)++(getListasFromTree b)++(getListasFromTree c)++(getListasFromTree d)


{- | Obtém a lista de movimentos até o jogador chegar à porta.
Se não chegar, devolve uma lista Vazia. -}
correrMovimentosAtePorta :: Jogo -> [Movimento] -> [Movimento] -> [Movimento]
correrMovimentosAtePorta (Jogo m (Jogador (a,b) c d)) [] l = []
correrMovimentosAtePorta (Jogo m (Jogador (a,b) c d)) (h:t) l
   | ((getPeca (x1,y1) mn) == Porta) = l++[h]
   | otherwise                       = correrMovimentosAtePorta (moveJogador (Jogo m (Jogador (a,b) c d)) h) t (l++[h])
          where (Jogo mn (Jogador (x1,y1) c1 d1)) = (moveJogador (Jogo m (Jogador (a,b) c d)) h)

