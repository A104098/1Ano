{- |
Module      : Tarefa3_2021li1g069
Description : Representação textual do jogo
Copyright   : João Pereira <a96350@alunos.uminho.pt>;
            : Luís Borges <a96357@alunos.uminho.pt>;

Módulo para a realização da Tarefa 3 do projeto de LI1 em 2021/22.
-}
module Tarefa3_2021li1g069 where

import LI12122


instance Show Jogo where
  show = concat . showJogo


{- | Recebe a Peça e retorna a String correspondente. -}
showPeca :: Peca -> String
showPeca Bloco = "X"
showPeca Caixa = "C"
showPeca Porta = "P"
showPeca Vazio = " "

{- | Recebe os dados do jogador e retorna ">" ou "<", conforme a direção para a qual ele estiver virado -}
showJogador :: Jogador -> String
showJogador (Jogador (a,b) Este c) = ">"
showJogador (Jogador (a,b) Oeste c) = "<"

{- Recebe o Jogo e retorna a String correspondente.
Para todas as peças não vazias, apenas aplica a função auxiliar showPeca.
Para as peças vazias, verifica se estão na posição do jogador e, se sim, aplica a função showJogador.-}
showJogo :: Jogo -> [String]
showJogo (Jogo ((Bloco:as):bs) (Jogador (a,b) c d)) | b == 0    = (showPeca Bloco):(showJogo (Jogo ((as):bs) (Jogador (a-1,b) c d)))
                                                    | otherwise = (showPeca Bloco):(showJogo (Jogo ((as):bs) (Jogador (a,b) c d)))
showJogo (Jogo ((Caixa:as):bs) (Jogador (a,b) c d)) | b == 0    = (showPeca Caixa):(showJogo (Jogo ((as):bs) (Jogador (a-1,b) c d)))
                                                    | otherwise = (showPeca Caixa):(showJogo (Jogo ((as):bs) (Jogador (a,b) c d)))
showJogo (Jogo ((Porta:as):bs) (Jogador (a,b) c d)) | b == 0    = (showPeca Porta):(showJogo (Jogo ((as):bs) (Jogador (a-1,b) c d)))
                                                    | otherwise = (showPeca Porta):(showJogo (Jogo ((as):bs) (Jogador (a,b) c d)))
showJogo (Jogo ((Vazio:as):bs) (Jogador (a,b) c d)) | (a /= 0) && (b == 0) = (showPeca Vazio):(showJogo (Jogo ((as):bs) (Jogador (a-1,b) c d)))
                                                    | (a /= 0) && (b /= 0) = (showPeca Vazio):(showJogo (Jogo ((as):bs) (Jogador (a,b) c d)))
                                                    | (a == 0) && (b == 0) = (showJogador (Jogador (a,b) c d)):(showJogo (Jogo ((as):bs) (Jogador (a-1,b-1) c d)))
showJogo (Jogo [[]] (Jogador (a,b) c d)) = [[]]
showJogo (Jogo ([]:as) (Jogador (a,b) c d)) = ["\n"] ++ (showJogo (Jogo as (Jogador (a,b-1) c d)))


