{- |
Module      : Tarefa5_2021li1g069
Description : Aplicação Gráfica Completa
Copyright   : João Pereira <a96350@alunos.uminho.pt>;
            : Luís Borges <a96357@alunos.uminho.pt>;

Módulo para a realização da Tarefa 5 do projeto de LI1 em 2021/22.
-}
module Main where 

import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game
import LI12122
import Tarefa1_2021li1g069
import Tarefa2_2021li1g069
import Tarefa3_2021li1g069
import Tarefa4_2021li1g069

type Player =  (Picture, Picture, (Float, Float),(Int, Int), Direcao, Bool)
type Caixas = [(Picture, (Float, Float), (Int, Int))]
type MapaGloss = Picture 
type YouWon = Picture

type Estado = (Mapa, MapaGloss, Player, Caixas, YouWon) 

dm :: Display
dm = InWindow "Mapa 1" (1700, 700) (0, 0)

fr :: Int
fr = 50

{- | Define o Estado Inicial do jogo -}
estadoInicial :: Mapa -> MapaGloss -> Picture -> Picture -> Picture -> YouWon -> Estado
estadoInicial mapa mapaGloss playerEste playerOeste caixa youWon = (mfinal, mapaGloss, (playerOeste, playerEste, (800, -200), (16,5), Oeste, False), [(caixa, (700, -200), (15,5)), (caixa, (600, -100), (14,4)), (caixa, (-600, -200), (2,5)), (caixa, (-700, -100), (1,4)), (caixa, (-800, 0), (0,3))],  youWon)

{- | Define, para qualquer situação, o que acontece quando qualquer tecla é pressionada. -}
reageEvento :: Event -> Estado -> Estado
-- Ao chegar à porta, não fazer nada
reageEvento (EventKey (SpecialKey KeyLeft) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (10,0), a, b), l, f) = (m, mg, (pE, pO, (glossx1,glossy1), (10,0), a, b), l, f)
reageEvento (EventKey (SpecialKey KeyRight) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (10,0), a, b), l, f) = (m, mg, (pE, pO, (glossx1,glossy1), (10,0), a, b), l, f)

-- Andar para a Esquerda sem caixa
reageEvento (EventKey (SpecialKey KeyLeft) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, False), l, f)   
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarEsquerda) == True) && (a==Oeste)  = (m, mg, (pE, pO, (glossx2,glossy2), (x2,y2), Oeste, False), l, f) 
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarEsquerda) == True) && (a==Este)   = (m, mg, (pO, pE, (glossx2,glossy2), (x2,y2), Oeste, False), l, f) 
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarEsquerda) == False) && (a==Oeste) = (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), Oeste, False), l, f)
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarEsquerda) == False) && (a==Este)  = (m, mg, (pO, pE, (glossx1,glossy1), (x1,y1), Oeste, False), l, f)                                                  
        where (glossx2,glossy2) = (cairOndeGloss (glossx1,glossy1) (x1,y1) ((cairOnde (desconstroiMapa m) (x1,y1) AndarEsquerda)))
              (x2,y2)           = (cairOnde (desconstroiMapa m) (x1,y1) AndarEsquerda)
   
-- Andar para a Esquerda com caixa   
reageEvento (EventKey (SpecialKey KeyLeft) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, True), l, f)   
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarEsquerda) == True) && (a==Oeste)  = (m, mg, (pE, pO, (glossx2,glossy2), (x2,y2), Oeste, True), ((caixa, (glossx2,glossy2+100), (fromIntegral x2,fromIntegral (y2-1))):t), f)   
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarEsquerda) == True) && (a==Este)   = (m, mg, (pO, pE, (glossx2,glossy2), (x2,y2), Oeste, True), ((caixa, (glossx2,glossy2+100), (fromIntegral x2,fromIntegral (y2-1))):t), f)   
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarEsquerda) == False) && (a==Oeste) = (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), Oeste, True), l, f) 
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarEsquerda) == False) && (a==Este)  = (m, mg, (pO, pE, (glossx1,glossy1), (x1,y1), Oeste, True), l, f)       
        where (glossx2,glossy2) = (cairOndeGloss (glossx1,glossy1) (x1,y1) ((cairOnde (desconstroiMapa m) (x1,y1) AndarEsquerda)))
              (x2,y2)           = (cairOnde (desconstroiMapa m) (x1,y1) AndarEsquerda)
              ((caixa, (glossxCaixa2,glossyCaixa2), (xCaixa2,yCaixa2))):t = changeCaixaNaLista m l (x1,y1) Oeste True AndarEsquerda

-- Andar para a Direita sem caixa
reageEvento (EventKey (SpecialKey KeyRight) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, False), l, f)  
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarDireita) == True) && (a==Oeste)  = (m, mg, (pO, pE, (glossx2,glossy2), (x2,y2), Este, False), l, f)
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarDireita) == True) && (a==Este)   = (m, mg, (pE, pO, (glossx2,glossy2), (x2,y2), Este, False), l, f)
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarDireita) == False) && (a==Oeste) = (m, mg, (pO, pE, (glossx1,glossy1), (x1,y1), Este, False), l, f)
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a False)) AndarDireita) == True) && (a==Este)   = (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), Este, False), l, f)
        where (glossx2,glossy2) = (cairOndeGloss (glossx1,glossy1) (x1,y1) ((cairOnde (desconstroiMapa m) (x1,y1) AndarDireita)))
              (x2,y2)           = (cairOnde (desconstroiMapa m) (x1,y1) AndarDireita)

-- Andar para a Direita com caixa
reageEvento (EventKey (SpecialKey KeyRight) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, True), l, f)  
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarDireita) == True) && (a==Oeste)  = (m, mg, (pO, pE, (glossx2,glossy2), (x2,y2), Este, True), ((caixa, (glossx2,glossy2+100), (fromIntegral x2,fromIntegral (y2-1))):t), f)   
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarDireita) == True) && (a==Este)   = (m, mg, (pE, pO, (glossx2,glossy2), (x2,y2), Este, True), ((caixa, (glossx2,glossy2+100), (fromIntegral x2,fromIntegral (y2-1))):t), f) 
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarDireita) == False) && (a==Oeste) = (m, mg, (pO, pE, (glossx1,glossy1), (x1,y1), Este, True), l, f)
  | ((checkIfPossible (Jogo m (Jogador (x1,y1) a True)) AndarDireita) == False) && (a==Este)  = (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), Este, True), l, f)
        where (glossx2,glossy2) = (cairOndeGloss (glossx1,glossy1) (x1,y1) ((cairOnde (desconstroiMapa m) (x1,y1) AndarDireita)))
              (x2,y2)           = (cairOnde (desconstroiMapa m) (x1,y1) AndarDireita)
              ((caixa, (glossxCaixa2,glossyCaixa2), (xCaixa2,yCaixa2))):t = changeCaixaNaLista m l (x1,y1) Oeste True AndarDireita

-- Trepar
reageEvento (EventKey (SpecialKey KeyUp) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, b), l, f) 
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) Trepar && (a == Este) && (b == False)  = (m, mg, (pE, pO, (glossx1+100,glossy1+100), (x1+1,y1-1), a, b), l, f) ----IMPORTANTE -> ao trepar, as primeiras cords aumentam mas as segundas diminuem
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) Trepar && (a == Oeste) && (b == False) = (m, mg, (pE, pO, (glossx1-100,glossy1+100), (x1-1,y1-1), a, b), l, f) 
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) Trepar && (a == Este) && (b == True)   = (m, mg, (pE, pO, (glossx1+100,glossy1+100), (x1+1,y1-1), a, b), (caixa, (glossx1+100,glossy1+200), (fromIntegral (x1+1),fromIntegral (y1-2))):t, f)
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) Trepar && (a == Oeste) && (b == True)  = (m, mg, (pE, pO, (glossx1-100,glossy1+100), (x1-1,y1-1), a, b), (caixa, (glossx1-100,glossy1+200), (fromIntegral (x1-1),fromIntegral (y1-2))):t, f) 
  | otherwise                                                                             = (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, b), l, f)
        where ((caixa, (glossxCaixa2,glossyCaixa2), (xCaixa2,yCaixa2))):t = changeCaixaNaLista m l (x1,y1) Oeste True AndarDireita

-- Pegar/Largar Caixa
reageEvento (EventKey (SpecialKey KeyDown) Down _ _) (m, mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, b), l, f) 
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) InterageCaixa && (a == Este) && (b == False)  = ((changeCaixa m (x1,y1) Este False),  mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, True),  (changeCaixaNaLista m l (x1,y1) a b InterageCaixa), f)
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) InterageCaixa && (a == Oeste) && (b == False) = ((changeCaixa m (x1,y1) Oeste False), mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, True),  (changeCaixaNaLista m l (x1,y1) a b InterageCaixa), f)
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) InterageCaixa && (a == Este) && (b == True)   = ((changeCaixa m (x1,y1) Este True),   mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, False), (changeCaixaNaLista m l (x1,y1) a b InterageCaixa), f)
  | checkIfPossible (Jogo m (Jogador (x1,y1) a b)) InterageCaixa && (a == Oeste) && (b == True)  = ((changeCaixa m (x1,y1) Oeste True),  mg, (pE, pO, (glossx1,glossy1), (x1,y1), a, False), (changeCaixaNaLista m l (x1,y1) a b InterageCaixa), f) -- não é 20, é 2_Oeste

-- Voltar ao início
reageEvento (EventKey (Char 'r') Down _ _) (m, mg, (pE, pO, (x1,y1), (x2,y2), a, b), [(caixa1, (x3,y3), (x4,y4)), (caixa2, (x5,y5), (x6,y6)), (caixa3, (x7,y7), (x8,y8)), (caixa4, (x9,y9), (x10,y10)), (caixa5, (x11,y11), (x12,y12))], f) 
  | a == Este  = (mfinal, mg, (pO, pE, (800,-200), (16,5), Oeste, False), [(caixa1, (700, -200), (15,5)), (caixa2, (600, -100), (14,4)), (caixa3, (-600, -200), (2,5)), (caixa4, (-700, -100), (1,4)), (caixa5, (-800, 0), (0,3))], f)
  | a == Oeste = (mfinal, mg, (pE, pO, (800,-200), (16,5), Oeste, False), [(caixa1, (700, -200), (15,5)), (caixa2, (600, -100), (14,4)), (caixa3, (-600, -200), (2,5)), (caixa4, (-700, -100), (1,4)), (caixa5, (-800, 0), (0,3))], f)
reageEvento (EventKey (Char 'R') Down _ _) (m, mg, (pE, pO, (x1,y1), (x2,y2), a, b), [(caixa1, (x3,y3), (x4,y4)), (caixa2, (x5,y5), (x6,y6)), (caixa3, (x7,y7), (x8,y8)), (caixa4, (x9,y9), (x10,y10)), (caixa5, (x11,y11), (x12,y12))], f) 
  | a == Este  = (mfinal, mg, (pO, pE, (800,-200), (16,5), Oeste, False), [(caixa1, (700, -200), (15,5)), (caixa2, (600, -100), (14,4)), (caixa3, (-600, -200), (2,5)), (caixa4, (-700, -100), (1,4)), (caixa5, (-800, 0), (0,3))], f)
  | a == Oeste = (mfinal, mg, (pE, pO, (800,-200), (16,5), Oeste, False), [(caixa1, (700, -200), (15,5)), (caixa2, (600, -100), (14,4)), (caixa3, (-600, -200), (2,5)), (caixa4, (-700, -100), (1,4)), (caixa5, (-800, 0), (0,3))], f)

-- Para qualquer outra tecla, não fazer nada (manter o estado)
reageEvento _ s = s


{- | Define o que acontece com o passar do tempo. -}
reageTempo :: Float -> Estado -> Estado   
reageTempo _ s = s


{- | Para cada Estado, devolve a versão gráfica desse Estado. -}
desenhaEstado :: Estado -> Picture
desenhaEstado (m4, mapa, (p1, p2, (glossx1,glossy1), (10,0), _ ,_), _, youWon) = youWon
desenhaEstado (m4, mapa, (p1, p2, (glossx1,glossy1), (_,_), _ ,_),  [(caixa1, (x2, y2), (_,_)), (caixa2, (x3, y3), (_,_)), (caixa3, (x4, y4), (_,_)), (caixa4, (x5, y5), (_,_)), (caixa5, (x6, y6), (_,_))], youWon) = pictures ([(translate 0 0 mapa)]++[translate x2 y2 caixa1]++[translate x3 y3 caixa2]++[translate x4 y4 caixa3]++[translate x5 y5 caixa4]++[translate x6 y6 caixa5]++[(translate glossx1 glossy1 p1)])


{- | Calcula a mudança nas coordenadas do Gloss, quando há um movimento do personagem. -}
cairOndeGloss :: (Float, Float) -> Coordenadas -> Coordenadas -> (Float, Float) 
cairOndeGloss (glossx1,glossy1) (x2,y2) (x3,y3) | x3 < x2     = ((glossx1-100), (glossy1-((fromIntegral (y3-y2))*100))) -- x3<x2 indica que o movimento é AndarEsquerda
                                                | otherwise   = ((glossx1+100), (glossy1-((fromIntegral (y3-y2))*100)))


{- | Calcula a mudança nas coordenadas do Gloss, quando uma caixa é largada. -}
dropCaixaGloss :: (Float, Float) -> Coordenadas -> Coordenadas -> (Float, Float)
dropCaixaGloss (glossxCaixa1, glossyCaixa1) (xCaixa1,yCaixa1) (xCaixa2, yCaixa2) | xCaixa2 < xCaixa1 = (glossxCaixa1-100, (glossyCaixa1-(fromIntegral (yCaixa2-yCaixa1)*(100))))
dropCaixaGloss (glossxCaixa1, glossyCaixa1) (xCaixa1,yCaixa1) (xCaixa2, yCaixa2) | otherwise         = (glossxCaixa1+100, (glossyCaixa1-(fromIntegral (yCaixa2-yCaixa1)*(100))))


{- | Altera, no mapa, a posição da Caixa, quando é feito o movimento InterageCaixa. -}
changeCaixa :: Mapa -> Coordenadas -> Direcao -> Bool -> Mapa 
changeCaixa m (x1,y1) Oeste False = constroiMapa (delCaixa (desconstroiMapa m) (x1,y1) Oeste)
changeCaixa m (x1,y1) Este False  = constroiMapa (delCaixa (desconstroiMapa m) (x1,y1) Este)
changeCaixa m (x1,y1) Oeste True = addCaixa m (x1,y1) Oeste   
changeCaixa m (x1,y1) Este True  = addCaixa m (x1,y1) Este 


{- | Muda, na lista de Caixas, as Coordenadas do Gloss da Caixa alterada, quando o movimento é InterageCaixa.
Para os outros movimentos, apenas põe a Caixa que é alterada como o primeiro elemento da lista. 
As coordenadas do gloss são alteradas, posteriormente, na função reageEvento. -}
changeCaixaNaLista :: Mapa -> Caixas -> Coordenadas -> Direcao -> Bool -> Movimento -> Caixas
changeCaixaNaLista m ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t) (x1,y1) a b InterageCaixa
  | ((xCaixa1,yCaixa1) == (x1+1,y1)) && (a==Este) && (b==False)  = (caixa1, (glossxCaixa1-100,glossyCaixa1+100), (xCaixa1-1,yCaixa1-1)):t
  | ((xCaixa1,yCaixa1) == (x1-1,y1)) && (a==Oeste) && (b==False) = (caixa1, (glossxCaixa1+100,glossyCaixa1+100), (xCaixa1+1,yCaixa1-1)):t
  | ((xCaixa1,yCaixa1) == (x1,y1-1)) && (a==Este) && (b==True)   = ((caixa1, (glossxCaixa2Este,glossyCaixa2Este), (xCaixa2Este, yCaixa2Este)):t)
  | ((xCaixa1,yCaixa1) == (x1,y1-1)) && (a==Oeste) && (b==True)  = ((caixa1, (glossxCaixa2Oeste,glossyCaixa2Oeste), (xCaixa2Oeste, yCaixa2Oeste)):t)
  | otherwise                                                    = (caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):(changeCaixaNaLista m t (x1,y1) a b InterageCaixa) 
      where (glossxCaixa2Este,glossyCaixa2Este) = dropCaixaGloss (glossxCaixa1,glossyCaixa1) (xCaixa1, yCaixa1) (dropCaixaWhere m (xCaixa1,yCaixa1) Este)
            (xCaixa2Este, yCaixa2Este) =  (dropCaixaWhere m (xCaixa1,yCaixa1) Este)
            (glossxCaixa2Oeste,glossyCaixa2Oeste) = dropCaixaGloss (glossxCaixa1,glossyCaixa1) (xCaixa1, yCaixa1) (dropCaixaWhere m (xCaixa1,yCaixa1) Oeste)
            (xCaixa2Oeste, yCaixa2Oeste) =  (dropCaixaWhere m (xCaixa1,yCaixa1) Oeste)

changeCaixaNaLista m ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t) (x1,y1) a True AndarEsquerda -- a ideia aqui é passar a caixa q o jogador tem em cima para o primeiro elemento da lista de caixas
  | (xCaixa1,yCaixa1) == (x1,y1-1) = ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t)
  | otherwise                      = (changeCaixaNaLista m t (x1,y1) a True AndarEsquerda)++[(caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1))]

changeCaixaNaLista m ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t) (x1,y1) a True AndarDireita -- a ideia aqui é passar a caixa q o jogador tem em cima para o primeiro elemento da lista de caixas
  | (xCaixa1,yCaixa1) == (x1,y1-1) = ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t)
  | otherwise                      = (changeCaixaNaLista m t (x1,y1) a True AndarDireita)++[(caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1))]

changeCaixaNaLista m ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t) (x1,y1) a True Trepar -- a ideia aqui é passar a caixa q o jogador tem em cima para o primeiro elemento da lista de caixas
  | (xCaixa1,yCaixa1) == (x1,y1-1) = ((caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1)):t)
  | otherwise                      = (changeCaixaNaLista m t (x1,y1) a True AndarDireita)++[(caixa1, (glossxCaixa1,glossyCaixa1), (xCaixa1,yCaixa1))]


{- | Quando uma caixa é largada, calcula as coordenadas onde deve cair. -}
dropCaixaWhere :: Mapa -> Coordenadas -> Direcao -> (Coordenadas)
dropCaixaWhere m (a,b) Este  | ((getPeca (a+1,b) m) == Vazio) = dropCaixaWhere m (a,b+1) Este  
                             | otherwise                      = (a+1, b-1)
dropCaixaWhere m (a,b) Oeste | ((getPeca (a-1,b) m) == Vazio) = dropCaixaWhere m (a,b+1) Oeste  
                             | otherwise                      = (a-1, b-1)




main :: IO ()
main = do 
    playerEste <- loadBMP "playerEste.bmp"
    playerOeste <- loadBMP "playerOeste.bmp"
    mapaGloss <- loadBMP "mapaFinal.bmp"
    caixa <- loadBMP "caixa.bmp"
    youWon <- loadBMP "youWon.bmp" 
    play dm                             -- janela onde irá correr o jogo
      (greyN 0.5)                       -- côr do fundo da janela
      fr                                -- frame rate
      (estadoInicial mfinal mapaGloss playerEste playerOeste caixa youWon) -- estado inicial
      desenhaEstado                     -- desenha o estado do jogo
      reageEvento                       -- reage a um evento
      reageTempo                        -- reage ao passar do tempo


mfinal :: Mapa 
mfinal = [ 
     [Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Porta, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio],
     [Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco, Bloco, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio],
     [Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco, Bloco, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio, Vazio],
     [Caixa, Vazio, Vazio, Vazio, Vazio, Bloco, Bloco, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Vazio, Vazio, Vazio, Vazio],
     [Bloco, Caixa, Vazio, Vazio, Vazio, Bloco, Bloco, Vazio, Bloco, Vazio, Vazio, Vazio, Bloco, Vazio, Caixa, Vazio, Vazio],
     [Bloco, Bloco, Caixa, Vazio, Vazio, Vazio, Vazio, Vazio, Bloco, Vazio, Vazio, Vazio, Bloco, Bloco, Bloco, Caixa, Vazio],
     [Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco, Bloco]]


